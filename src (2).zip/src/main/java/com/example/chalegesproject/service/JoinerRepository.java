package com.example.chalegesproject.service;

import com.example.chalegesproject.model.Joiner;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JoinerRepository extends JpaRepository<Joiner,Long> {
}
