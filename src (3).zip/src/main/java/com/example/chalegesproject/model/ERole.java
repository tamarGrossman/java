package com.example.chalegesproject.model;

public enum ERole {
    ROLE_USER,
    ROLE_MODERATOR,//עובד
    ROLE_ADMIN
}