package com.example.chalegesproject.dto;

public record ChatResponse(String message) {
}
