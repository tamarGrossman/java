package com.example.chalegesproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChalegesProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
