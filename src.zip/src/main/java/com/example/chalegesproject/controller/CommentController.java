package com.example.chalegesproject.controller;

import com.example.chalegesproject.dto.CommentDto;
import com.example.chalegesproject.model.Comment;
import com.example.chalegesproject.service.ChallengeRepository;
import com.example.chalegesproject.service.CommentMapper;
import com.example.chalegesproject.service.CommentRepository;
import com.example.chalegesproject.service.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
@RestController
public class CommentController   {
    private final CommentRepository commentRepository;
    private final UsersRepository usersRepository;
    private final ChallengeRepository challengeRepository;
    private final CommentMapper commentMapper;


    @Autowired
    public CommentController(CommentRepository commentRepository,
                             UsersRepository usersRepository,
                             ChallengeRepository challengeRepository,
                             CommentMapper commentMapper) {
        this.commentRepository = commentRepository;
        this.usersRepository = usersRepository;
        this.challengeRepository = challengeRepository;
        this.commentMapper = commentMapper;
    }
    @GetMapping
    public List<CommentDto> getAllComments() {
        List<Comment> comments = commentRepository.findAll();

        return comments.stream()
                .<CommentDto>map(comment -> {
                    try {
                        return commentMapper.commentToDto(comment);
                    } catch (IOException e) {
                        throw new RuntimeException("Error mapping Comment to CommentDTO", e);
                    }
                })
                .collect(Collectors.toList());
    }






}
