package com.example.chalegesproject.controller;

import com.example.chalegesproject.dto.ChallengeDto;
import com.example.chalegesproject.model.Challenge;
import com.example.chalegesproject.service.ChallengeMapper;
import com.example.chalegesproject.service.ChallengeRepository;
import com.example.chalegesproject.service.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;


    @RestController
    @RequestMapping("/challenges")
    public class ChallengeController {

        private final ChallengeRepository challengeRepository;
        private final UsersRepository usersRepository;
        private final ChallengeMapper challengeMapper;

        @Autowired
        public ChallengeController(ChallengeRepository challengeRepository,
                                   UsersRepository usersRepository,
                                   ChallengeMapper challengeMapper) {
            this.challengeRepository = challengeRepository;
            this.usersRepository = usersRepository;
            this.challengeMapper = challengeMapper;
        }

        // --- GET כל האתגרים ---
        @GetMapping
        public List<ChallengeDto> getAllChallenges() {
            List<Challenge> challenges = challengeRepository.findAll();

            return challenges.stream()
                    .<ChallengeDto>map(challenge -> {
                        try {
                            return challengeMapper.challengeToDto(challenge);
                        } catch (IOException e) {
                            throw new RuntimeException("Error mapping Challenge to ChallengeDTO", e);
                        }
                    })
                    .collect(Collectors.toList());
        }

        // --- POST יצירת אתגר חדש ---
        @PostMapping
        public ChallengeDto createChallenge(@RequestBody ChallengeDto challengeDTO) {
            try {
                Challenge challenge = challengeMapper.dtoToChallenge(challengeDTO);
                Challenge saved = challengeRepository.save(challenge);
                return challengeMapper.challengeToDto(saved);
            } catch (IOException e) {
                throw new RuntimeException("Error mapping ChallengeDTO to Challenge", e);
            }
        }
    }


