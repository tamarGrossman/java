package com.example.chalegesproject.service;

import com.example.chalegesproject.dto.ChallengeDto;
import com.example.chalegesproject.model.Challenge;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
@Component
public interface ChallengeMapper {
    List<ChallengeDto> challengesToDto(List<Challenge> challenges);
    Challenge challengeDTOtoChallenge(ChallengeDto dto);

    // המרה עם טיפול בתמונה
    default ChallengeDto challengeToDto(Challenge challenge) throws IOException {
        ChallengeDto dto = new ChallengeDto();

        dto.setId(challenge.getId());
        dto.setName(challenge.getName());
        dto.setDescription(challenge.getDescription());
        dto.setDate(challenge.getDate());
        dto.setNumOfDays(challenge.getNumOfDays());

        // המרת התמונה לקובץ base64 כך שאפשר להציג אותה ב-Frontend
        if (challenge.getPicture() != null) {
            dto.setPicture(ImageUtils.getImage(challenge.getPicture()));
        }

        return dto;
    }

    // המרה הפוכה — שמירת התמונה שהועלתה
    default Challenge dtoToChallenge(ChallengeDto dto) throws IOException {
        Challenge challenge = new Challenge();

        challenge.setId(dto.getId());
        challenge.setName(dto.getName());
        challenge.setDescription(dto.getDescription());
        challenge.setDate(dto.getDate());
        challenge.setNumOfDays(dto.getNumOfDays());

        // שמירת התמונה לקובץ במערכת
        if (dto.getPicture() != null) {
            String path = ImageUtils.saveImage(dto.getPicture());
            challenge.setPicture(path);
        }

        return challenge;
    }
}
