package com.example.chalegesproject.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

public class ImageUtils {
    // המרה מתמונה מקובץ ל-Base64
    public static String getImage(String imagePath) throws IOException {
        Path path = Paths.get(imagePath);
        byte[] bytes = Files.readAllBytes(path);
        return Base64.getEncoder().encodeToString(bytes);
    }

    // שמירה של תמונה שנשלחה כ-Base64 לקובץ במערכת
    public static String saveImage(String base64Image) throws IOException {
        byte[] bytes = Base64.getDecoder().decode(base64Image);
        String fileName = "uploads/" + System.currentTimeMillis() + ".jpg";
        Path path = Paths.get(fileName);
        Files.createDirectories(path.getParent());
        Files.write(path, bytes);
        return fileName;
    }
}
